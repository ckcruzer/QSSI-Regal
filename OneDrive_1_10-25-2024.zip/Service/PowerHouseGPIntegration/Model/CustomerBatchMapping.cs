﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BSP.PowerHouse.DynamicsGP.Integration.Model
{
    public class CustomerBatchMapping
    {
        public string CUSTNMBR { get; set; }
        public string BACHNUMB { get; set; }
    }
}
