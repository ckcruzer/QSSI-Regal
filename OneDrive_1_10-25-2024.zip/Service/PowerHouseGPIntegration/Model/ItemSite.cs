﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BSP.PowerHouse.DynamicsGP.Integration.Model
{
    public class ItemSite
    {
        public string ItemNumber { get; set; }
        public string SiteId { get; set; }
    }
}
