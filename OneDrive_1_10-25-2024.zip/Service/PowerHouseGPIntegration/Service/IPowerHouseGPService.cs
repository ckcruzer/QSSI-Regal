﻿namespace BSP.PowerHouse.DynamicsGP.Integration.Service
{
    public interface IPowerHouseGPService
    {
        void Process();
    }
}
