namespace BSP.PowerHouse.DynamicsGP.Integration.Domain
{
    public partial class InventoryUofMSchedule
    {
        public string UOMSCHDL { get; set; }
        public string UMSCHDSC { get; set; }
        public decimal NOTEINDX { get; set; }
        public string BASEUOFM { get; set; }
        public short UMDPQTYS { get; set; }
        public System.DateTime DEX_ROW_TS { get; set; }
        public int DEX_ROW_ID { get; set; }
    }
}
