﻿
namespace BSP.PowerHouse.DynamicsGP.Integration.Domain
{
    public partial class BoxSizeItemMaster
    {
        public string ITEMNMBR { get; set; }
        public string BOXSZEID { get; set; }
        public decimal WEIGHT { get; set; }
        public int Count1 { get; set; }
        public decimal PERITEMCUBE { get; set; }
        public decimal APW { get; set; }
        public decimal NOTEINDX { get; set; }
        public string MDFUSRID { get; set; }
        public System.DateTime MODIFDT { get; set; }
        public string CRUSRID { get; set; }
        public System.DateTime CREATDDT { get; set; }
        public int DEX_ROW_ID { get; set; }
    }
}