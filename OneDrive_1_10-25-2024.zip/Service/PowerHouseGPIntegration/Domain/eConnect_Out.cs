
namespace BSP.PowerHouse.DynamicsGP.Integration.Domain
{
    public partial class eConnect_Out
    {
        public string DOCTYPE { get; set; }
        public System.DateTime DATE1 { get; set; }
        public string TABLENAME { get; set; }
        public int DEX_ROW_ID { get; set; }
        public string INDEX1 { get; set; }
        public string INDEX2 { get; set; }
        public string INDEX3 { get; set; }
        public string INDEX4 { get; set; }
        public string INDEX5 { get; set; }
        public string INDEX6 { get; set; }
        public string INDEX7 { get; set; }
        public string INDEX8 { get; set; }
        public string INDEX9 { get; set; }
        public string INDEX10 { get; set; }
        public string INDEX11 { get; set; }
        public string INDEX12 { get; set; }
        public string INDEX13 { get; set; }
        public string INDEX14 { get; set; }
        public string INDEX15 { get; set; }
        public int ACTION { get; set; }
        public int REPLICATE { get; set; }
        public string DBNAME { get; set; }
    }
}
