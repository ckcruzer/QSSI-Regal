namespace BSP.PowerHouse.DynamicsGP.Integration.Domain
{
    public partial class InventoryUofMScheduleDetail
    {
        public string UOMSCHDL { get; set; }
        public string UOFM { get; set; }
        public int SEQNUMBR { get; set; }
        public string EQUIVUOM { get; set; }
        public decimal EQUOMQTY { get; set; }
        public decimal QTYBSUOM { get; set; }
        public string UOFMLONGDESC { get; set; }
        public System.DateTime DEX_ROW_TS { get; set; }
        public int DEX_ROW_ID { get; set; }
    }
}
