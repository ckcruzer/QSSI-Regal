
namespace BSP.PowerHouse.DynamicsGP.Integration.Domain
{
    public partial class ItemCurrencyMaster
    {
        public string ITEMNMBR { get; set; }
        public string CURNCYID { get; set; }
        public short CURRNIDX { get; set; }
        public short DECPLCUR { get; set; }
        public decimal LISTPRCE { get; set; }
        public int DEX_ROW_ID { get; set; }
    }
}
