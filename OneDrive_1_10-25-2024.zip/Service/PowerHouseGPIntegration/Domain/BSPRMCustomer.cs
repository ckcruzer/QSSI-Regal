﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BSP.PowerHouse.DynamicsGP.Integration.Domain
{
    public partial class BSPRMCustomer
    {
        public string CUSTNMBR { get; set; }
        public int BSP_SuppressPHFreight { get; set; }
    }
}
