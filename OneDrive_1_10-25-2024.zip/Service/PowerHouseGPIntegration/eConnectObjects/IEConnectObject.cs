﻿
namespace BSP.PowerHouse.DynamicsGP.Integration.eConnectObjects
{
    public interface IEConnectObject
    {
        string GetXmlSerializedObject();
    }
}
