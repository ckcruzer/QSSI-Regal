USE [REGAL]
GO
/****** Object:  StoredProcedure [dbo].[BSP_GET_ESI11004_DATA]    Script Date: 2/8/2023 10:43:04 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		BSP
-- Create date: 
-- Description:	
-- =============================================
ALTER PROCEDURE [dbo].[BSP_GET_ESI11004_DATA] 
	-- Add the parameters for the stored procedure here
	@pMSTRNUMB int,
	@pLNITMSEQ int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT  ISNULL([ESISACAM_1], 0) [ESISACAM_1]
	FROM [ESI11004]
	WHERE MSTRNUMB = @pMSTRNUMB AND LNITMSEQ = @pLNITMSEQ
END
