﻿using System;

namespace BSP.DynamicsGP.PowerHouse.Models
{
    public class RecordNotesMaster
    {
        public decimal NoteIndex { get; set; }
        public string TextField { get; set; }
        public DateTime Date { get; set; }
        public DateTime Time { get; set; }
    }
}
