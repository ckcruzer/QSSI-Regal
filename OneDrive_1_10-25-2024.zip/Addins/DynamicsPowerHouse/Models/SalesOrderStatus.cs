﻿namespace BSP.DynamicsGP.PowerHouse.Models
{
    public class SalesOrderStatus
    {
        public string OrderId { get; set; }
        public string ReleaseNum { get; set; }
        public string Status { get; set; }
    }
}
