README
This README would normally document whatever steps are necessary to get your application up and running.
What is this repository for?
* 
* NetSuite Integration with customer database to create, cancel and update subscriptions in NetSuite and push to Enact Subscription Software.
* Retrieve usage information from Enact Subscription Software.
* Automatically Bill Subscriptions in NetSuite on a schedule, after retrieving usage information from customer's database.
How do I get set up?
* This is a BSP managed bundle in the Z Collaboration development NetSuite instance.
Contribution guidelines
Who do I talk to?
* Ric Paras rparas@bspny.com
* Bahaa Hussein bhussein@bspny.com

